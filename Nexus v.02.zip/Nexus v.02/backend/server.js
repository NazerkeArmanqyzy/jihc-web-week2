import http from "node:http";
import { json } from "co-body";
import pg from "pg";

const { Pool } = pg;

const pool = new Pool({
  host: process.env.PGHOST || "localhost",
  port: Number(process.env.PGPORT || 5432),
  user: process.env.PGUSER || "nazerke",
  password: process.env.PGPASSWORD || undefined,
  database: process.env.PGDATABASE || "cinema_nexus"
});

const send = (res, status, data) => {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
};

const server = http.createServer(async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  try {
    const url = new URL(req.url, "http://localhost");
    const path = url.pathname;

    if (req.method === "GET" && path === "/") {
      res.writeHead(200, { "Content-Type": "text/plain" });
      return res.end("Cinema Nexus API is running");
    }

    if (req.method === "GET" && path === "/users") {
      const { rows } = await pool.query(`
        SELECT
          id,
          username,
          full_name AS "fullName",
          email
        FROM users
        ORDER BY id
      `);

      return send(res, 200, rows);
    }

    if (req.method === "POST" && ["/register", "/login"].includes(path)) {
      const body = await json(req);

      if (path === "/register") {
        const { username, fullName, email, password } = body;

        if (!username || !password) {
          return send(res, 400, {
            message: "Username and password are required"
          });
        }

        try {
          const result = await pool.query(
            `
              INSERT INTO users (username, full_name, email, password)
              VALUES ($1, $2, $3, $4)
              RETURNING id
            `,
            [username, fullName || null, email || null, password]
          );

          return send(res, 201, {
            message: "User registered successfully",
            id: result.rows[0].id
          });
        } catch (error) {
          if (error.code === "23505") {
            return send(res, 409, {
              message: "Username already exists"
            });
          }

          throw error;
        }
      }

      const result = await pool.query(
        `
          SELECT id
          FROM users
          WHERE username = $1 AND password = $2
        `,
        [body.username, body.password]
      );

      const valid = result.rowCount > 0;

      return send(res, valid ? 200 : 401, {
        message: valid ? "Login successful" : "Invalid username or password"
      });
    }

    const userRoute = path.match(/^\/users\/(\d+)$/);

    if (userRoute && req.method === "PUT") {
      const userId = Number(userRoute[1]);
      const body = await json(req);
      const username = typeof body.username === "string" ? body.username.trim() : "";

      if (!username) {
        return send(res, 400, { message: "Username is required" });
      }

      try {
        const result = await pool.query(
          `
            UPDATE users
            SET username = $1
            WHERE id = $2
            RETURNING id, username, full_name AS "fullName", email
          `,
          [username, userId]
        );

        if (result.rowCount === 0) {
          return send(res, 404, { message: "User not found" });
        }

        return send(res, 200, {
          message: "Username updated successfully",
          user: result.rows[0]
        });
      } catch (error) {
        if (error.code === "23505") {
          return send(res, 409, { message: "Username already exists" });
        }

        throw error;
      }
    }

    if (userRoute && req.method === "DELETE") {
      const userId = Number(userRoute[1]);
      const result = await pool.query(
        "DELETE FROM users WHERE id = $1 RETURNING id",
        [userId]
      );

      if (result.rowCount === 0) {
        return send(res, 404, { message: "User not found" });
      }

      return send(res, 200, {
        message: "User deleted successfully",
        id: result.rows[0].id
      });
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Route not found");
  } catch (error) {
    console.error(error);
    send(res, 500, { message: "Internal server error" });
  }
});

server.listen(5001, () => {
  console.log("Server is running on http://localhost:5001");
});

process.on("SIGINT", async () => {
  await pool.end();
  process.exit(0);
});
